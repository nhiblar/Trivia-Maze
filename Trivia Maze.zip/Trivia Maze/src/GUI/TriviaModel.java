package GUI;

public class TriviaModel {

	private int submitValue;
	
	public void setSubmitValue(int aNumber) {
		
		submitValue = aNumber;
		
	}
	
	public int getSubmitValue() {
		return submitValue;
	}

	
}
package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.event.EventListenerList;

@SuppressWarnings("serial")
public class MyButtonGroup extends ButtonGroup {
  
	private ActionListener btnGrpListener = new BtnGrpListener();
	private EventListenerList listenerList = new EventListenerList();

   @Override
   public void add(AbstractButton b) {
      b.addActionListener(btnGrpListener);
      super.add(b);
   }

   public void addActionListener(ActionListener listener) {
      listenerList.add(ActionListener.class, listener);
   }

   protected void fireActionListeners() {
      Object[] listeners = listenerList.getListenerList();
      String actionCommand = "help, i need somebody, help, not just anybody...";
      ButtonModel model = getSelection();
      if (model != null) {
         actionCommand = model.getActionCommand();
      }
      ActionEvent ae = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, actionCommand);
      for (int i = listeners.length-2; i>=0; i-=2) {
          if (listeners[i]== ActionListener.class) {
              ((ActionListener)listeners[i+1]).actionPerformed(ae);
          }
      }
   }

   private class BtnGrpListener implements ActionListener {

      public void actionPerformed(ActionEvent ae) {
         fireActionListeners();
      }
   }
}